const Exchange = () => {
  return (
    <div className="page">
      Exchange Page
    </div>
  );
}

export default Exchange;