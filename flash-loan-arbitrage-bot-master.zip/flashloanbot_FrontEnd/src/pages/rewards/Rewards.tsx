const Rewards = () => {
  return (
    <div className="page">
      Rewards Page
    </div>
  );
}

export default Rewards;