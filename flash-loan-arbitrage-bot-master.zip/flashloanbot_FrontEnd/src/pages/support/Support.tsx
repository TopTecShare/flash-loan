const Support = () => {
  return (
    <div className="page">
      Support Page
    </div>
  );
}

export default Support;